# Evm Wallet Android

Android Gradle project for displaying native EVM balances from an authorized backend/provider.

## Build on GitHub

The repository includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.
It uses JDK 17 and Gradle 8.9, then builds `app-debug.apk` and uploads it as the `EvmWallet-debug-apk` artifact.

## Production endpoint

`MainActivity.kt` currently uses `http://127.0.0.1:3000` for the backend API.
For an online deployment, replace `apiBase` with your authorized HTTPS backend URL. Do not place private keys, signing secrets, provider API secrets, or license secrets in the APK.

## Current app behavior

- Accepts a public EVM wallet address.
- Calls `GET /balance/{address}` on the configured backend.
- Supports `balanceEth` directly or `balanceWei` with Wei-to-ETH conversion.
- Shows a fetching state and connection/HTTP/parse errors.
