package com.example.evmwallet

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import org.json.JSONObject
import java.io.IOException
import java.math.BigDecimal
import java.math.RoundingMode

class MainActivity : AppCompatActivity() {
    private val client = OkHttpClient()
    private val apiBase = "http://127.0.0.1:3000"
    private val weiInEth = BigDecimal("1000000000000000000")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val address = EditText(this).apply {
            hint = "0x public wallet address"
            setSingleLine(true)
        }
        val balance = TextView(this).apply {
            text = "Balance: —"
            textSize = 22f
            setPadding(0, 32, 0, 32)
        }
        val button = Button(this).apply { text = "Get on-chain balance" }

        button.setOnClickListener {
            val walletAddress = address.text.toString().trim()
            if (walletAddress.isEmpty()) {
                Toast.makeText(this, "Enter a public wallet address", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            balance.text = "Fetching balance..."
            button.isEnabled = false

            val request = Request.Builder()
                .url("$apiBase/balance/$walletAddress")
                .get()
                .build()

            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    runOnUiThread {
                        button.isEnabled = true
                        balance.text = "Connection error: ${e.message}"
                    }
                }

                override fun onResponse(call: Call, response: Response) {
                    val body = response.body?.string().orEmpty()
                    runOnUiThread {
                        button.isEnabled = true
                        if (response.isSuccessful) {
                            try {
                                val json = JSONObject(body)
                                val ethFormatted = when {
                                    json.has("balanceEth") -> json.getString("balanceEth")
                                    json.has("balanceWei") -> {
                                        val wei = BigDecimal(json.getString("balanceWei"))
                                        wei.divide(weiInEth, 6, RoundingMode.HALF_UP)
                                            .stripTrailingZeros().toPlainString()
                                    }
                                    else -> "—"
                                }
                                balance.text = "Balance: $ethFormatted ETH"
                            } catch (e: Exception) {
                                balance.text = "Parse error: ${e.message}"
                            }
                        } else {
                            balance.text = "Error ${response.code}: $body"
                        }
                    }
                }
            })
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
            addView(address)
            addView(button)
            addView(balance)
        }
        setContentView(layout)
    }
}
